<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('add_ons', function (Blueprint $table) {
            $table->id();
            $table->string('key')->unique(); // message_credits, extra_staff, extra_storage...
            $table->string('name');
            $table->string('status')->default('active');
            $table->json('config_json')->nullable(); // pricing rules, limits
            $table->timestamps();
        });

        Schema::create('store_add_ons', function (Blueprint $table) {
            $table->id();
            $table->foreignId('store_id')->constrained('stores')->cascadeOnDelete();
            $table->foreignId('add_on_id')->constrained('add_ons')->restrictOnDelete();

            $table->string('status')->default('active');
            $table->timestamp('starts_at')->nullable();
            $table->timestamp('ends_at')->nullable();

            $table->json('data')->nullable(); // purchased qty, overrides
            $table->timestamps();

            $table->unique(['store_id', 'add_on_id']);
            $table->index(['store_id', 'status']);
        });

        Schema::create('store_message_credit_balances', function (Blueprint $table) {
            $table->id();
            $table->foreignId('store_id')->unique()->constrained('stores')->cascadeOnDelete();

            $table->integer('balance')->default(0);
            $table->timestamps();
        });

        Schema::create('store_message_credit_transactions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('store_id')->constrained('stores')->cascadeOnDelete();

            $table->string('type'); // topup/debit/adjustment
            $table->integer('amount'); // +/-
            $table->string('reference_type')->nullable();
            $table->string('reference_id')->nullable();
            $table->text('note')->nullable();

            $table->timestamps();

            $table->index(['store_id', 'type']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('store_message_credit_transactions');
        Schema::dropIfExists('store_message_credit_balances');
        Schema::dropIfExists('store_add_ons');
        Schema::dropIfExists('add_ons');
    }
};
