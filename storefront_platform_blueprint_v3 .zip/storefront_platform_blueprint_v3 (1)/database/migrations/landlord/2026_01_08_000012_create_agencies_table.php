<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('agencies', function (Blueprint $table) {
            $table->id();

            $table->string('name');
            $table->string('status')->default('active'); // active/suspended

            $table->unsignedBigInteger('owner_user_id')->nullable(); // users.id
            $table->string('email')->nullable();
            $table->string('phone')->nullable();

            $table->json('data')->nullable();

            $table->timestamps();

            $table->index(['status']);
            $table->index(['owner_user_id']);
        });

        Schema::create('agency_store', function (Blueprint $table) {
            $table->foreignId('agency_id')->constrained('agencies')->cascadeOnDelete();
            $table->foreignId('store_id')->constrained('stores')->cascadeOnDelete();

            $table->string('role')->default('manager'); // manager/viewer
            $table->timestamps();

            $table->primary(['agency_id', 'store_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('agency_store');
        Schema::dropIfExists('agencies');
    }
};
