<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('billing_plans', function (Blueprint $table) {
            $table->id();

            $table->string('name');
            $table->string('fee_mode')->default('flat'); // flat|percent|hybrid

            $table->decimal('flat_fee', 12, 2)->default(0);       // e.g. 5.00
            $table->decimal('percent_fee', 6, 3)->default(0);     // e.g. 1.000 = 1%

            $table->decimal('min_fee', 12, 2)->nullable();
            $table->decimal('max_fee', 12, 2)->nullable();

            $table->string('status')->default('active');

            $table->timestamps();

            $table->index(['status']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('billing_plans');
    }
};
