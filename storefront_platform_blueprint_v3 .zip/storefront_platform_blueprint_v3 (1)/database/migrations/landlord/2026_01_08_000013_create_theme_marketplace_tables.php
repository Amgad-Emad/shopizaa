<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('theme_vendors', function (Blueprint $table) {
            $table->id();

            $table->string('name');
            $table->string('status')->default('active'); // active/suspended

            $table->unsignedBigInteger('owner_user_id')->nullable(); // users.id
            $table->string('email')->nullable();
            $table->string('phone')->nullable();

            $table->json('payout_json')->nullable(); // payout method details (phase 2)
            $table->timestamps();

            $table->index(['status']);
        });

        Schema::table('themes', function (Blueprint $table) {
            $table->unsignedBigInteger('theme_vendor_id')->nullable()->after('created_by');
            $table->boolean('is_marketplace')->default(false)->after('theme_vendor_id');
            $table->decimal('price', 12, 2)->nullable()->after('is_marketplace');
            $table->string('currency', 3)->default('EGP')->after('price');

            $table->index(['theme_vendor_id']);
            $table->index(['is_marketplace']);
        });

        Schema::create('theme_purchases', function (Blueprint $table) {
            $table->id();

            $table->foreignId('store_id')->constrained('stores')->cascadeOnDelete();
            $table->foreignId('theme_id')->constrained('themes')->restrictOnDelete();
            $table->foreignId('theme_version_id')->constrained('theme_versions')->restrictOnDelete();

            $table->decimal('price', 12, 2);
            $table->string('currency', 3)->default('EGP');

            $table->string('status')->default('paid'); // paid/refunded
            $table->timestamp('purchased_at')->nullable();

            // platform share (snapshot)
            $table->decimal('platform_commission_percent', 6, 3)->default(30.000);
            $table->decimal('platform_commission_amount', 12, 2)->default(0);

            $table->timestamps();

            $table->index(['store_id', 'status']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('theme_purchases');

        Schema::table('themes', function (Blueprint $table) {
            $table->dropColumn(['theme_vendor_id', 'is_marketplace', 'price', 'currency']);
        });

        Schema::dropIfExists('theme_vendors');
    }
};
