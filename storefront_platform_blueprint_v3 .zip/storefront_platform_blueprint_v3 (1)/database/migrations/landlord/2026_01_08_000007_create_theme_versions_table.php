<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('theme_versions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('theme_id')->constrained('themes')->cascadeOnDelete();

            $table->string('version'); // 1.0.0
            $table->text('changelog')->nullable();
            $table->boolean('is_latest')->default(false);

            $table->timestamps();

            $table->unique(['theme_id', 'version']);
            $table->index(['theme_id', 'is_latest']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('theme_versions');
    }
};
