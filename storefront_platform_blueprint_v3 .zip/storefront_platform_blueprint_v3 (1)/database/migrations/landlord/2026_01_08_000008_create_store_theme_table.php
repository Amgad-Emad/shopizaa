<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('store_theme', function (Blueprint $table) {
            $table->id();
            $table->foreignId('store_id')->unique()->constrained('stores')->cascadeOnDelete();
            $table->foreignId('theme_id')->constrained('themes')->restrictOnDelete();
            $table->foreignId('theme_version_id')->constrained('theme_versions')->restrictOnDelete();

            // Per-store theme settings (colors, fonts, layout toggles...)
            $table->json('settings_json')->nullable();

            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('store_theme');
    }
};
