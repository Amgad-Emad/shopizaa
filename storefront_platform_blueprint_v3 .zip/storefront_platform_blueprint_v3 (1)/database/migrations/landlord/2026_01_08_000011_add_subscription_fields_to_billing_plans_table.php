<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('billing_plans', function (Blueprint $table) {
            $table->decimal('monthly_price', 12, 2)->default(0)->after('name');
            $table->json('features_json')->nullable()->after('percent_fee'); // limits/add-ons flags
        });
    }

    public function down(): void
    {
        Schema::table('billing_plans', function (Blueprint $table) {
            $table->dropColumn(['monthly_price', 'features_json']);
        });
    }
};
