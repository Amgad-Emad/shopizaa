<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('store_settings', function (Blueprint $table) {
            $table->id();
            $table->foreignId('store_id')->unique()->constrained('stores')->cascadeOnDelete();

            $table->string('timezone')->default('Africa/Cairo');
            $table->string('support_email')->nullable();
            $table->string('support_phone')->nullable();

            $table->json('address_json')->nullable();
            $table->json('social_links_json')->nullable();
            $table->json('policies_json')->nullable();

            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('store_settings');
    }
};
