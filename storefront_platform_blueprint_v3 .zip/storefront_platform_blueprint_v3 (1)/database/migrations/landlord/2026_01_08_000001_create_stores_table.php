<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('stores', function (Blueprint $table) {
            $table->id();

            $table->string('name');
            $table->string('slug')->unique(); // subdomain key (store1)
            $table->string('status')->default('active'); // active/suspended

            // Spatie Multitenancy: tenant database name
            $table->string('database')->unique(); // e.g. tenant_store_1

            // Optional metadata
            $table->json('data')->nullable();

            $table->unsignedBigInteger('owner_user_id')->nullable(); // landlord users.id
            $table->string('default_currency', 3)->default('EGP');

            $table->timestamps();

            $table->index(['status']);
            $table->index(['owner_user_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('stores');
    }
};
