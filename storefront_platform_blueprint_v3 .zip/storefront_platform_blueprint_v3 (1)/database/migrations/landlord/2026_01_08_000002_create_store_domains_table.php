<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('store_domains', function (Blueprint $table) {
            $table->id();
            $table->foreignId('store_id')->constrained('stores')->cascadeOnDelete();

            $table->string('domain')->unique(); // store1.example.com or mystore.com
            $table->string('type')->default('subdomain'); // subdomain/custom
            $table->boolean('is_primary')->default(true);

            $table->timestamps();

            $table->index(['store_id', 'is_primary']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('store_domains');
    }
};
