<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('marketing_campaigns', function (Blueprint $table) {
            $table->id();

            $table->string('name');
            $table->string('channel'); // whatsapp/sms/email
            $table->string('type')->default('broadcast'); // broadcast/abandoned_cart

            $table->string('status')->default('draft'); // draft/running/paused/completed
            $table->json('audience_json')->nullable(); // segment rules
            $table->json('content_json')->nullable();  // templates
            $table->timestamp('scheduled_at')->nullable();

            $table->timestamps();

            $table->index(['status']);
            $table->index(['channel', 'type']);
        });

        Schema::create('marketing_message_logs', function (Blueprint $table) {
            $table->id();

            $table->foreignId('campaign_id')->nullable()->constrained('marketing_campaigns')->nullOnDelete();
            $table->foreignId('customer_id')->nullable()->constrained('customers')->nullOnDelete();

            $table->string('channel'); // whatsapp/sms/email
            $table->string('status')->default('queued'); // queued/sent/delivered/failed
            $table->string('provider_message_id')->nullable();

            $table->json('payload_json')->nullable();
            $table->text('error_message')->nullable();

            $table->timestamps();

            $table->index(['channel', 'status']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('marketing_message_logs');
        Schema::dropIfExists('marketing_campaigns');
    }
};
