<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('order_fees', function (Blueprint $table) {
            $table->id();

            $table->foreignId('order_id')->unique()->constrained('orders')->cascadeOnDelete();

            // Snapshot from landlord billing plan at time of order:
            $table->string('fee_mode_snapshot'); // flat/percent/hybrid
            $table->decimal('flat_fee_snapshot', 12, 2)->default(0);
            $table->decimal('percent_fee_snapshot', 6, 3)->default(0);

            $table->string('calculated_on')->default('grand_total'); // grand_total/subtotal
            $table->decimal('fee_amount', 12, 2)->default(0);

            $table->string('currency', 3)->default('EGP');

            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('order_fees');
    }
};
