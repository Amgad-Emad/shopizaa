<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('order_risk_assessments', function (Blueprint $table) {
            $table->id();

            $table->foreignId('order_id')->unique()->constrained('orders')->cascadeOnDelete();

            $table->unsignedInteger('score')->default(0); // 0-100
            $table->string('level')->default('low'); // low/medium/high
            $table->json('signals_json')->nullable(); // reasons (new customer + COD + high value...)
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('order_risk_assessments');
    }
};
