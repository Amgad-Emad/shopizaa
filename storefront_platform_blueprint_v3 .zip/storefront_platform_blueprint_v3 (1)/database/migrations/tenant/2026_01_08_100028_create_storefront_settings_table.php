<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('storefront_settings', function (Blueprint $table) {
            $table->id();

            $table->foreignId('homepage_page_id')->nullable()->constrained('pages')->nullOnDelete();

            $table->json('brand_json')->nullable();
            $table->json('seo_json')->nullable();
            $table->json('analytics_json')->nullable();
            $table->json('checkout_json')->nullable();
            $table->json('social_links_json')->nullable();
            $table->json('policies_json')->nullable();

            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('storefront_settings');
    }
};
