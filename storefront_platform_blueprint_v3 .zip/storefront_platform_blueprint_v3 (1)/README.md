# Multi-Tenant Storefront Hosting Platform (Laravel + MySQL)

## 1. Overview
This project is a multi-tenant e-commerce platform that hosts storefront websites for merchants (stores) under subdomains (e.g. `store1.example.com`).
The platform earns a commission per successful order (initially **5 EGP per successful order**, later configurable as **percentage (e.g. 1%)** or hybrid).

## 2. Tenancy Strategy (Spatie Laravel Multitenancy)
- **Landlord (Central DB):** platform data (stores/tenants, domains, themes, plans, platform users/staff, roles/permissions, media for platform assets).
- **Tenant (Per-Store DB):** store data (products, bundles, offers, customers, orders, inventory, CMS pages, etc.).

Tenant is resolved by hostname (subdomain/custom domain) via `store_domains.domain`, then Spatie Multitenancy switches the database connection to the tenant DB.

## 3. Tech Stack
- Laravel (latest)
- MySQL
- Breeze (web authentication for dashboards)
- JWT for API authentication (customer app)
- Spatie Laravel Multitenancy (tenant switching by domain)
- Spatie Media Library (images: platform theme assets + tenant product/CMS images)
- Spatie Roles & Permissions (store-scoped via `store_id` teams)
- PHPUnit/Pest for tests

## 4. Dashboards (4)
### A) Platform Super Admin
- Manage stores/tenants & domains, suspend/activate stores
- Create themes + versions + assets (publish/unpublish)
- Define billing plans (flat/%/hybrid) and subscriptions
- Global analytics and system settings

### B) Store Dashboard (Merchant + Staff)
- Products, variants, categories, inventory
- Bundles, discounts, coupons
- Orders, payments, shipping, refunds
- CMS pages, menus, homepage builder (blocks)
- Choose theme from published themes + adjust theme settings
- Staff invitations + roles/permissions

### C) Platform Ops / Finance
- Payouts (phase 2), settlements, approvals
- Fraud/suspicious order review
- Support escalation across stores

### D) Customer Portal (per store)
- Customer login (tenant)
- Order history + tracking
- Addresses + profile

## 5. Commission Model (Now & Later)
### MVP
- Flat fee: **5.00 EGP** per successful order

### Later
- Percentage fee (e.g. **1%**) or hybrid using `billing_plans`:
  - `fee_mode`: `flat | percent | hybrid`
  - `flat_fee`, `percent_fee`, optional `min_fee`, `max_fee`
- Store plan stored in `store_subscriptions`
- Order fee **snapshotted** at checkout in tenant DB table `order_fees`

## 6. Database Layout
### 6.1 Landlord DB (Central)
- stores
- store_domains
- store_settings
- billing_plans
- store_subscriptions
- themes
- theme_versions
- store_theme
- permissions/roles tables (Spatie, store-scoped by store_id)
- media (Spatie Media Library - platform assets)

### 6.2 Tenant DB (Per Store)
- categories
- products
- product_variants
- attributes, attribute_values, variant_attribute_values
- inventory_items, inventory_movements
- bundles, bundle_items
- discounts, discount_rules, coupons
- pages, page_blocks, menus, menu_items
- storefront_settings (homepage + SEO + analytics + checkout config)
- customers, customer_addresses
- orders, order_items, order_item_components, order_status_history
- payments, shipments, refunds
- order_fees
- media (Spatie Media Library - tenant uploads)

## 7. CMS (Per Store / Tenant)
Each store includes a lightweight CMS:
- **Pages** (`pages`) with publish/draft states
- **Page blocks** (`page_blocks`) to build pages using sections (hero, banner, grid, HTML, FAQ, etc.)
- **Menus** (`menus`, `menu_items`) for header/footer navigation
- **Storefront settings** (`storefront_settings`) for homepage, SEO, analytics, and checkout behavior
- **Media**: Spatie Media Library table (`media`) exists inside each tenant DB so store media is isolated

## 8. Theme Selection (Store chooses from Super Admin active themes)
- Super Admin creates themes and sets `themes.status = published` when ready.
- Store dashboard can only list/apply themes where `themes.status = published`.
- Applied theme is stored in landlord table `store_theme`:
  - `store_id`, `theme_id`, `theme_version_id`, `settings_json`
- Theme settings can be stored in:
  - `store_theme.settings_json` (landlord, when needed at resolve-time)
  - `tenant.storefront_settings` (tenant UI/CMS settings)

## 9. Architecture & Best Practices
- Service Layer for business logic (`OrderService`, `PricingService`, `InventoryService`, `CmsService`)
- Repositories for data access
- Form Requests for validation
- Policies/Gates for authorization
- Domain Events & Jobs for side effects (emails, webhooks, retries)
- Idempotency for payment callbacks

## 10. Testing (Required)
- Tenant isolation tests (store A cannot access store B)
- Fee calculation tests (flat/percent/hybrid with min/max)
- Checkout happy path + failure paths
- Inventory oversell prevention
- Coupon usage limits
- Double webhook callback idempotency
## 11. Growth, Retention & Monetization Enhancements (High ROI)
### 11.1 Onboarding & Imports
- 3-minute store wizard (theme → first products → shipping/payment)
- CSV import + WooCommerce/Shopify import (phase 2)
- Ready-made starter store templates per niche

### 11.2 Egypt/MENA Commerce Features
- COD as a first-class payment method
- COD verification (OTP/WhatsApp confirm) to reduce fake orders
- WhatsApp-first sharing links with tracking

### 11.3 Marketing Automation (Retention)
- Abandoned cart tracking + recovery messages (WhatsApp/SMS/Email)
- Campaigns + message logs
- Pixel integrations (Meta/TikTok/Google) via settings

### 11.4 Theme Marketplace (New Revenue Stream)
- Designers/vendors can publish themes (reviewed)
- Theme purchases per store + platform commission (e.g. 30%)
- Versioned themes (already supported by `theme_versions`)

### 11.5 Partner / Agency Dashboard (Growth Multiplier)
- Agencies manage multiple stores for clients
- Reseller / referral tracking (phase 2)
- Optional white-label tier (phase 3)

### 11.6 Risk & Fraud Controls
- Suspicious order scoring
- Blacklists (phone/device) (phase 2)
- Payment webhook idempotency keys

### 11.7 Pricing Model (Better Profit)
Use hybrid monetization (recommended):
- Monthly subscription plan (Starter/Pro/Business)
- + per-order fee (flat / percent / hybrid)
- + paid add-ons (extra staff, message credits, storage, custom domain, etc.)
